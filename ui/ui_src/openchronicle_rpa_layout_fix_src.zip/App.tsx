import { useEffect, useMemo, useState } from "react";

import { Sidebar } from "./components/layout/Sidebar";
import { Topbar } from "./components/layout/Topbar";
import { ProviderStudio } from "./pages/rpa/ProviderStudio";
import { RealtimeConsole } from "./pages/rpa/RealtimeConsole";

const routeByNav: Record<string, string> = {
  总览: "/rpa/realtime",
  实时调试: "/rpa/realtime",
  "RPA Provider 管理": "/rpa/providers",
  设备舰队: "/rpa/providers",
  "Workflow 库": "/rpa/providers",
  技能构建: "/rpa/providers",
  执行器: "/rpa/realtime",
  "Trace 回放": "/rpa/realtime",
  安全审批: "/rpa/realtime",
  记忆中心: "/rpa/providers",
  设置: "/rpa/providers"
};

export function App() {
  const [path, setPath] = useState(() => window.location.pathname === "/" ? "/rpa/realtime" : window.location.pathname);
  const [activeProvider, setActiveProvider] = useState("android_adb");
  const activeNav = path.includes("/rpa/providers") ? "RPA Provider 管理" : "实时调试";
  const title = path.includes("/rpa/providers") ? "RPA Provider 管理与 Workflow Studio" : "实时调试控制台";

  useEffect(() => {
    if (window.location.pathname === "/") {
      window.history.replaceState(null, "", "/rpa/realtime");
    }
    const onPop = () => setPath(window.location.pathname);
    window.addEventListener("popstate", onPop);
    return () => window.removeEventListener("popstate", onPop);
  }, []);

  const page = useMemo(() => {
    if (path.includes("/rpa/providers")) {
      return <ProviderStudio activeProvider={activeProvider} onProviderChange={setActiveProvider} />;
    }
    return <RealtimeConsole activeProvider={activeProvider} onProviderChange={setActiveProvider} />;
  }, [activeProvider, path]);

  function navigate(label: string) {
    const nextPath = routeByNav[label] ?? "/rpa/realtime";
    window.history.pushState(null, "", nextPath);
    setPath(nextPath);
  }

  return (
    <div className="h-screen min-h-0 w-full overflow-hidden bg-slate-50">
      <Sidebar active={activeNav} onNavigate={navigate} />
      <div className="flex h-full min-h-0 min-w-0 flex-col pl-[232px]">
        <Topbar title={title} activeProvider={activeProvider} onProviderChange={setActiveProvider} />
        <main className="min-h-0 flex-1 overflow-y-auto overflow-x-hidden p-4 lg:p-5">{page}</main>
      </div>
    </div>
  );
}
